from setuptools import setup

setup(
  name='pixel_art',
  version='0.1',
  description='Pckage for drawing pixel art to the terminal.',
  author='Thomas',
  packages=['pixel_art'],
  install_requires=['colorama']
)